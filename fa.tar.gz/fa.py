import boto3
from time import sleep
from concurrent.futures import ThreadPoolExecutor
import configparser


def aws_xmr(
        account: str,
        aws_access_key_id: str,
        aws_secret_access_key: str,
        aws_session_token: str,
        region_name: str,
        vm_count: int,
        instance_type: str,
        image_id: str,
        user_data: str,
        retries: int,
        retry_interval: int
):
    client = boto3.client(
        'ec2',
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
        aws_session_token=aws_session_token,
        region_name=region_name
    )
    retried = 0

    while True:
        try:
            if retried >= retries:
                print(f'{account}: error')
                break

            client.run_instances(
                ImageId=image_id,
                InstanceType=instance_type,
                MinCount=1,
                MaxCount=vm_count,
                UserData=user_data
            )
            print(f'{account}: done')
            break
        except Exception as e:
            print(f'{e}')
            sleep(retry_interval)
            retried += 1


if __name__ == '__main__':

    try:
        user_data = open('UserData.txt', 'r', encoding='utf-8').read()

        config = configparser.ConfigParser()
        config.read('Config.ini', encoding='utf-8')
        region_name = config['default']['region_name']
        vm_count = int(config['default']['vm_count'])
        instance_type = config['default']['instance_type']
        image_id = config['default']['image_id']
        retries = int(config['default']['retries'])
        retry_interval = int(config['default']['retry_interval'])
        threads = int(config['default']['threads'])

        executor = ThreadPoolExecutor(max_workers=threads)
        thread_pool = []

        credentials = configparser.ConfigParser()
        credentials.read('Credentials.ini', encoding='utf-8')
        for account in credentials.sections():
            aws_access_key_id = credentials[account]['aws_access_key_id']
            aws_secret_access_key = credentials[account]['aws_secret_access_key']
            aws_session_token = credentials[account]['aws_session_token'] \
                if credentials.has_option(account, 'aws_session_token') else ''

            thread_pool.append(
                executor.submit(
                    aws_xmr,
                    account,
                    aws_access_key_id,
                    aws_secret_access_key,
                    aws_session_token,
                    region_name,
                    vm_count,
                    instance_type,
                    image_id,
                    user_data,
                    retries,
                    retry_interval
                )
            )

    except Exception as e:
        print(f'{e}')
